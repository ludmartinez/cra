<?php

namespace App\Http\Controllers;

use App\Http\Requests\StorePeriodo;
use App\Http\Requests\UpdatePeriodo;
use App\Periodo;
use Illuminate\Http\Request;

class PeriodoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $segment = $request->segment(2);
        $periodos = Periodo::all();

        return view('admin.periodos.index', compact('segment', 'periodos'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StorePeriodo $request)
    {
        $periodo = Periodo::create($request->all());

        return response()->json($periodo->toArray());
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Periodo  $periodo
     * @return \Illuminate\Http\Response
     */
    public function show(Periodo $periodo)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Periodo  $periodo
     * @return \Illuminate\Http\Response
     */
    public function edit(Periodo $periodo)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Periodo  $periodo
     * @return \Illuminate\Http\Response
     */
    public function update(UpdatePeriodo $request, Periodo $periodo)
    {
        $periodo->update($request->all());
        $periodo = Periodo::find($request->id);
        return response()->json($periodo->toArray());
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Periodo  $periodo
     * @return \Illuminate\Http\Response
     */
    public function destroy(Periodo $periodo)
    {
        Periodo::destroy($periodo->id);
        return response()->json(['message' => 'Período eliminado con éxito']);
    }
}
