<?php

use Faker\Generator as Faker;

$factory->define(App\Municipio::class, function (Faker $faker) {
    return [
        //
    ];
});
