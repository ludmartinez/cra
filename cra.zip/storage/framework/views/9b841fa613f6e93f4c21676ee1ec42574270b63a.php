<table class="table table-responsive-sm table-hover shadow listado" id="tablaGrados">
    <thead class="thead-dark">
        <tr>
            <th scope="col">Id</th>
            <th scope="col">Grado</th>
            <th scope="col">Creado</th>
            <th scope="col">Editado</th>
            <th scope="col">Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $grados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="row<?php echo e($grado->id); ?>">
            <td><?php echo e($grado->id); ?></td>
            <td><?php echo e($grado->grado); ?></td>
            <td><?php echo e(date('d/m/Y H:i:s', strtotime($grado->created_at))); ?></td>
            <td><?php echo e(date('d/m/Y H:i:s', strtotime($grado->updated_at))); ?></td>
            <td class="text-center">
                <a href="<?php echo e(route('grados.show', ['grado'=>$grado, 'p'=>1])); ?>" class="btn btn-primary"><i class="fas fa-eye"></i></a>
                <button type="button" class="btn btn-warning" onclick="editar(<?php echo e($grado->id); ?>,'<?php echo e(route('grados.update', $grado)); ?>')"><i class="fas fa-edit"></i></button>
                <button type="button" class="btn btn-danger" onclick="eliminar(<?php echo e($grado->id); ?>,'<?php echo e(route('grados.destroy', $grado)); ?>')"><i
                        class="fas fa-trash-alt"></i></button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<script>
    function eliminar(id, url) {
        var grado =  $('tr#row'+id).find('td').eq(1).text();
        $.confirm({
            icon: 'fas fa-exclamation-triangle',
            title: '¡Advertencia!',
            content: 'Está a punto de eliminar el grado: <b><mark>' + grado + '</mark></b>, ¿Está seguro?',
            type: 'red',
            buttons: {
                Confirmar: {
                    btnClass: 'btn btn-danger',
                    action: function () {
                        $.ajax({
                            url: url,
                            headers: {
                                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                            },
                            type: 'DELETE',
                            success: function (response) {
                                $('.listado').dataTable().fnDestroy();
                                $('#row' + id).remove();
                                loadTable();
                                marcar();
                                toastr.options = {
                                    "closeButton": true,
                                    "debug": false,
                                    "newestOnTop": true,
                                    "progressBar": true,
                                    "positionClass": "toast-bottom-right",
                                    "preventDuplicates": false,
                                    "onclick": null,
                                    "showDuration": "400",
                                    "hideDuration": "1000",
                                    "timeOut": "5000",
                                    "extendedTimeOut": "1000",
                                    "showEasing": "swing",
                                    "hideEasing": "linear",
                                    "showMethod": "fadeIn",
                                    "hideMethod": "fadeOut"
                                };
                                toastr.success('Registro eliminado con éxito.',
                                    '¡En hora buena!');
                            },
                            error: function (msj) {
                                toastr.options = {
                                    "closeButton": true,
                                    "debug": false,
                                    "newestOnTop": true,
                                    "progressBar": true,
                                    "positionClass": "toast-bottom-right",
                                    "preventDuplicates": false,
                                    "onclick": null,
                                    "showDuration": "400",
                                    "hideDuration": "1000",
                                    "timeOut": "5000",
                                    "extendedTimeOut": "1000",
                                    "showEasing": "swing",
                                    "hideEasing": "linear",
                                    "showMethod": "fadeIn",
                                    "hideMethod": "fadeOut"
                                };
                                toastr.error('No se pudo eliminar el registro', '¡Lo sentimos!');
                            }
                        });
                    }
                },
                Cancelar: function () {},
            }
        });
    }
</script>
