<table class="table table-responsive-sm table-hover shadow listado" id="tablaDocentes">
    <thead class="thead-dark">
        <tr>
            <th scope="col">Carnet</th>
            <th scope="col">DUI</th>
            <th scope="col">Nombre</th>
            <th scope="col">Sexo</th>
            <th scope="col">Fecha de Nacimiento</th>
            <th scope="col">Fecha de Ingreso</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $docentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr onclick="location.href='<?php echo e(route('docentes.show', $docente)); ?>'" style="cursor:pointer">
            <td><?php echo e($docente->carnet); ?></td>
            <td><?php echo e($docente->dui); ?></td>
            <td><?php echo e($docente->fullName()); ?></td>
            <td><?php echo e($docente->sexo); ?></td>
            <td><?php echo e(date("d/m/Y",strtotime($docente->fechaNacimiento))); ?></td>
            <td><?php echo e(date("d/m/Y",strtotime($docente->fechaIngreso))); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

