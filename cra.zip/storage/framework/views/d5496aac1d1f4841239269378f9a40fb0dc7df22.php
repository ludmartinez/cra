<?php $helper = app('App\CustomHelpers\StringHelper'); ?>
<table class="table table-responsive-sm table-hover shadow listado" id="tablaAdmins">
    <thead class="thead-dark">
        <tr>
            <th scope="col">Carnet</th>
            <th scope="col">DUI</th>
            <th scope="col">Nombre</th>
            <th scope="col">Sexo</th>
            <th scope="col">Tipo</th>
            <th scope="col">Fecha de Nacimiento</th>
            <th scope="col">Fecha de Ingreso</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr onclick="location.href='<?php echo e(route('admins.show', $admin)); ?>'" style="cursor:pointer">
            <td><?php echo e($admin->carnet); ?></td>
            <td><?php echo e($admin->dui); ?></td>
            <td><?php echo e($helper->fullName($admin->primerNombre,$admin->segundoNombre,$admin->tercerNombre,$admin->apellidoPaterno,$admin->apellidoMaterno)); ?></td>
            <td><?php echo e($admin->sexo); ?></td>
            <td><?php if($admin->superUsuario == true): ?> Master <?php else: ?> Normal <?php endif; ?></td>
            <td><?php echo e(date("d/m/Y",strtotime($admin->fechaNacimiento))); ?></td>
            <td><?php echo e(date("d/m/Y",strtotime($admin->fechaIngreso))); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

