<?php $__env->startSection('contenido'); ?>
<div class="row">
    <div class="col-12 bg-secondary text-white">
        <h3 class="text-center">Listado de Admins</h3>
    </div>
</div>

<section id="listadoAdmins" class="mdl-tabs mdl-js-tabs mdl-js-ripple-effect">

    <div class="mdl-tabs__tab-bar sticky-top bg-light">
        <a href="#activos-panel" class="mdl-tabs__tab is-active">Activos</a>
        <a href="#inactivos-panel" class="mdl-tabs__tab">Inactivos</a>
    </div>

    <div class="mdl-tabs__panel is-active p-2 container" id="activos-panel">
        <?php $__env->startComponent('admin.admins.partials.admins', ['admins' => $adminsActivos]); ?> <?php echo $__env->renderComponent(); ?>
    </div>
    <div class="mdl-tabs__panel p-2 container" id="inactivos-panel">
        <?php $__env->startComponent('admin.admins.partials.admins', ['admins' => $adminsInactivos]); ?> <?php echo $__env->renderComponent(); ?>
    </div>

</section>

<style>
    #btnAgregarAdmin {
        position: fixed;
        display: block;
        right: 0;
        bottom: 0;
        margin-right: 30px;
        margin-bottom: 30px;
        z-index: 900;
    }
</style>
<!-- Colored FAB button with ripple -->
<a id="btnAgregarAdmin" class="mdl-button mdl-js-button mdl-button--fab mdl-js-ripple-effect mdl-button--colored mdl-color-text--white"
    href="<?php echo e(route('admins.create')); ?>">
    <i class="material-icons">add</i>
</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
$('.mdl-tabs__tab-bar a').click(function(){
    $('input[type="search"]').val('');
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>