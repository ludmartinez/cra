<table class="table table-responsive-sm table-hover shadow listado" id="tablaAlumnos">
    <thead class="thead-dark">
        <tr>
            <th scope="col">Carnet</th>
            <th scope="col">NIE</th>
            <th scope="col">Nombre</th>
            <th scope="col">Sexo</th>
            <th scope="col">Solvencia</th>
            <th scope="col">Fecha de Nacimiento</th>
            <th scope="col">Fecha de Ingreso</th>
        </tr>
    </thead>
    <tbody id="paginated">
        <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr onclick="location.href='<?php echo e(route('alumnos.show', $alumno->carnet)); ?>'" style="cursor:pointer">
            <td><?php echo e($alumno->carnet); ?></td>
            <td><?php echo e($alumno->nie); ?></td>
            <td><?php echo e($alumno->fullName()); ?></td>
            <td><?php echo e($alumno->sexo); ?></td>
            <td><?php if($alumno->solvencia): ?> Solvente <?php else: ?> Insolvente <?php endif; ?></td>
            <td><?php echo e(date("d/m/Y",strtotime($alumno->fechaNacimiento))); ?></td>
            <td><?php echo e(date("d/m/Y",strtotime($alumno->fechaIngreso))); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

