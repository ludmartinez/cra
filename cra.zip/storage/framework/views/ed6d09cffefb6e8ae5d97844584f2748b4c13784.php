<?php $__env->startSection('contenido'); ?>
<section class="container">
    <h3>Listado de Matriculas</h3>
    <hr>
    <table class="table table-responsive-sm table-hover shadow listado" id="tablamatriculaes">
        <thead class="thead-dark">
            <tr>
                <th scope="col">Período</th>
                <th scope="col">Alumno</th>
                <th scope="col">Edad</th>
                <th scope="col">Sexo</th>
                <th scope="col">Grado</th>
                <th scope="col">Tiempo en institución</th>
                <th scope="col">Fecha de Matricula</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $matriculas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matricula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($matricula->periodo); ?></td>
                <td><?php echo e($matricula->alumno); ?></td>
                <td><?php echo e($matricula->edad); ?></td>
                <td><?php echo e($matricula->sexo); ?></td>
                <td><?php echo e($matricula->grado); ?></td>
                <td><?php echo e($matricula->tiempoInstitucion); ?></td>
                <td><?php echo e($matricula->fechaMatricula); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>