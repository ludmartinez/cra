<div class="row">
    <div class="col">
        <button class="btn btn-primary pull-right mb-3" onclick="agregar()">Agregar</button>
    </div>
</div>
<table class="table table-responsive-sm table-hover shadow listado" id="tablaAsignaciones">
    <thead class="thead-dark">
        <tr>
            <th scope="col">Período</th>
            <th scope="col">Materia</th>
            <th scope="col">Grado</th>
            <th scope="col">Creado</th>
            <th scope="col">Editado</th>
            <th scope="col">Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $asignaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asignacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="row<?php echo e($asignacion->id); ?>">
            <td><?php echo e($asignacion->periodo->periodo); ?></td>
            <td><?php echo e($asignacion->materia->materia); ?></td>
            <td><?php echo e($asignacion->grado->grado); ?></td>
            <td><?php echo e($asignacion->created_at); ?></td>
            <td><?php echo e($asignacion->updated_at); ?></td>
            <td class="text-center">
                <button type="button" class="btn btn-warning" onclick="editar(<?php echo e($asignacion->id); ?>, '<?php echo e(route('asignaciones.update', $asignacion)); ?>')"><i class="fas fa-edit"></i></button>
                <button type="button" class="btn btn-danger" onclick="eliminar(<?php echo e($asignacion->id); ?>, '<?php echo e(route('asignaciones.destroy', $asignacion)); ?>')"><i class="fas fa-trash-alt"></i></button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<script>
    function agregar() {
        var contenido = '<form id="formAsignacion">' +
                '<div class="form-group">' +
                '<label for="periodo">Periodo</label>' +
                '<select id="periodo" class="form-control">' +
                '<option value="">--seleccionar--</option>'+
                '<?php $__currentLoopData = $periodos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $periodo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($periodo->id); ?>"><?php echo e($periodo->periodo); ?></periodo> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>'+
                '</select>'+
                '</div>'+
                '<div class="form-group">' +
                '<label for="materia">Materia</label>' +
                '<select id="materia" class="form-control">' +
                '<option value="">--seleccionar--</option>'+
                '<?php $__currentLoopData = $materias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($materia->id); ?>"><?php echo e($materia->materia); ?></materia> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>'+
                '</select>'+
                '</div>'+
                '<div class="form-group">' +
                '<label for="grado">Grado</label>' +
                '<select id="grado" class="form-control" >'+
                '<option value="">--seleccionar--</option>'+
                '<?php $__currentLoopData = $grados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($grado->id); ?>"><?php echo e($grado->grado); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>'+
                '</select>'+
                '</div>'+
                '</form>';
        $.confirm({
            icon: 'fas fa-keyboard',
            closeIcon: true,
            escapeKey: true,
            backgroundDismiss: true,
            title: 'Agregar Asignación',
            content: contenido,
            type: 'blue',
            buttons: {
                agregar: {
                    text: 'Agregar',
                    btnClass: 'btn btn-blue',
                    action: function () {
                        var datos = new FormData();
                        datos.append('periodo_id', $('#periodo').val());
                        datos.append('docente_carnet', "<?php echo e($docente->carnet); ?>");
                        datos.append('materia_id', $('#materia').val());
                        datos.append('grado_id', $('#grado').val());

                        $.ajax({
                            url: '<?php echo e(route("asignaciones.store")); ?>',
                            headers: {
                                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                            },
                            type: 'POST',
                            contentType: false,
                            processData: false,
                            cache: false,
                            data: datos,
                            beforeSend: function () {
                                $('form#formAsignacion input').removeClass('is-invalid');
                                $('#formAsignacion').removeClass('was-validated');
                            },
                            success: function (response) {
                                var url = '<?php echo e(url("/admin/asignaciones")); ?>/'+response.asignacion.id;
                                $('#formAsignacion').addClass('was-validated');
                                var row = '<tr id="row'+response.asignacion.id+'">'
                                    row += '<td>'+response.periodo+'</td>'
                                    row += '<td>'+response.materia+'</td>'
                                    row += '<td>'+response.grado+'</td>'
                                    row += '<td>'+response.asignacion.created_at+'</td>'
                                    row += '<td>'+response.asignacion.updated_at+'</td>'
                                    row += '<td class="text-center">'
                                    row += '<button type="button" class="btn btn-warning" onclick="editar('+response.asignacion.id+', \''+url+'\')"><i class="fas fa-edit"></i></button>'
                                    row += ' <button type="button" class="btn btn-danger" onclick="eliminar('+response.asignacion.id+', \''+url+'\')"><i class="fas fa-trash-alt"></i></button>'
                                    row += '</td></tr>'
                                $('.listado').dataTable().fnDestroy();
                                $('#tablaAsignaciones').find('tbody').append(row);
                                loadTable();
                                marcar();
                                toastr.options = {
                                    "closeButton": true,
                                    "debug": false,
                                    "newestOnTop": true,
                                    "progressBar": true,
                                    "positionClass": "toast-bottom-right",
                                    "preventDuplicates": false,
                                    "onclick": null,
                                    "showDuration": "400",
                                    "hideDuration": "1000",
                                    "timeOut": "5000",
                                    "extendedTimeOut": "1000",
                                    "showEasing": "swing",
                                    "hideEasing": "linear",
                                    "showMethod": "fadeIn",
                                    "hideMethod": "fadeOut"
                                };
                                toastr.success('Asignación agregada con éxito.',
                                    '¡En hora buena!');
                            },
                            error: function (msj) {
                                console.log(msj);
                                if(msj.responseJSON.error != undefined){
                                    toastr.options = {
                                        "closeButton": true,
                                        "debug": false,
                                        "newestOnTop": true,
                                        "progressBar": true,
                                        "positionClass": "toast-bottom-right",
                                        "preventDuplicates": false,
                                        "onclick": null,
                                        "showDuration": "400",
                                        "hideDuration": "1000",
                                        "timeOut": "5000",
                                        "extendedTimeOut": "1000",
                                        "showEasing": "swing",
                                        "hideEasing": "linear",
                                        "showMethod": "fadeIn",
                                        "hideMethod": "fadeOut"
                                    };
                                    toastr.error(msj.responseJSON.error, '¡Lo sentimos!');
                                }
                                if (msj.responseJSON.errors.periodo_id != undefined) {
                                    $('#periodo').addClass('is-invalid');
                                    toastr.options = {
                                        "closeButton": true,
                                        "debug": false,
                                        "newestOnTop": true,
                                        "progressBar": true,
                                        "positionClass": "toast-bottom-right",
                                        "preventDuplicates": false,
                                        "onclick": null,
                                        "showDuration": "400",
                                        "hideDuration": "1000",
                                        "timeOut": "5000",
                                        "extendedTimeOut": "1000",
                                        "showEasing": "swing",
                                        "hideEasing": "linear",
                                        "showMethod": "fadeIn",
                                        "hideMethod": "fadeOut"
                                    };
                                    toastr.error(msj.responseJSON.errors.periodo_id, '¡Lo sentimos!');
                                }
                                if (msj.responseJSON.errors.grado_id != undefined) {
                                    $('#grado').addClass('is-invalid');
                                    toastr.options = {
                                        "closeButton": true,
                                        "debug": false,
                                        "newestOnTop": true,
                                        "progressBar": true,
                                        "positionClass": "toast-bottom-right",
                                        "preventDuplicates": false,
                                        "onclick": null,
                                        "showDuration": "400",
                                        "hideDuration": "1000",
                                        "timeOut": "5000",
                                        "extendedTimeOut": "1000",
                                        "showEasing": "swing",
                                        "hideEasing": "linear",
                                        "showMethod": "fadeIn",
                                        "hideMethod": "fadeOut"
                                    };
                                    toastr.error(msj.responseJSON.errors.grado_id, '¡Lo sentimos!');
                                }
                                if (msj.responseJSON.errors.docente_carnet != undefined) {
                                    toastr.options = {
                                        "closeButton": true,
                                        "debug": false,
                                        "newestOnTop": true,
                                        "progressBar": true,
                                        "positionClass": "toast-bottom-right",
                                        "preventDuplicates": false,
                                        "onclick": null,
                                        "showDuration": "400",
                                        "hideDuration": "1000",
                                        "timeOut": "5000",
                                        "extendedTimeOut": "1000",
                                        "showEasing": "swing",
                                        "hideEasing": "linear",
                                        "showMethod": "fadeIn",
                                        "hideMethod": "fadeOut"
                                    };
                                    toastr.error(msj.responseJSON.errors.docente_carnet, '¡Lo sentimos!');
                                }
                                if (msj.responseJSON.errors.materia_id != undefined) {
                                    toastr.options = {
                                        "closeButton": true,
                                        "debug": false,
                                        "newestOnTop": true,
                                        "progressBar": true,
                                        "positionClass": "toast-bottom-right",
                                        "preventDuplicates": false,
                                        "onclick": null,
                                        "showDuration": "400",
                                        "hideDuration": "1000",
                                        "timeOut": "5000",
                                        "extendedTimeOut": "1000",
                                        "showEasing": "swing",
                                        "hideEasing": "linear",
                                        "showMethod": "fadeIn",
                                        "hideMethod": "fadeOut"
                                    };
                                    toastr.error(msj.responseJSON.errors.materia_id, '¡Lo sentimos!');
                                }
                            }
                        });
                    }
                },
                Cancelar: {

                }
            },
            onContentReady: function () {
                // bind to events
                var jc = this;
                this.$content.find('form#formAsignacion').on('submit', function (e) {
                    // if the user submits the form by pressing enter in the field.
                    e.preventDefault();
                    jc.$$agregar.trigger('click'); // reference the button and click it
                });
            },
        });
    }

    function editar(id, url) {
        var periodo =  $('tr#row'+id).find('td').eq(0).text();
        var materia =  $('tr#row'+id).find('td').eq(1).text();
        $.confirm({
            icon: 'fas fa-keyboard',
            title: 'Editar Matricula '+periodo,
            content: '' +
                '<form id="formAsignacion">' +
                '<div class="form-group">' +
                '<label for="periodo">Materia</label>' +
                '<input id="periodo" type="text" class="form-control" value="'+periodo+'" readonly>'+
                '</div>' +
                '<div class="form-group">' +
                '<label for="materia">Materia</label>' +
                '<input id="materia" type="text" class="form-control" value="'+materia+'" readonly>'+
                '</div>' +
                '<div class="form-group">' +
                '<label for="grado">Grado</label>' +
                '<select id="grado" class="form-control">' +
                '<option value="" selected>--Seleccionar--</option>'+
                '<?php $__currentLoopData = $grados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($grado->id); ?>"><?php echo e($grado->grado); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>'+
                '</select>'+
                '</div>' +
                '</form>',
            type: 'orange',
            buttons: {
                editar: {
                    text: 'Editar',
                    btnClass: 'btn btn-warning',
                    action: function () {
                        var datos = new FormData();
                        datos.append('_method', 'PUT');
                        datos.append('grado_id', $('#grado').val());

                        $.ajax({
                            url: url,
                            headers: {
                                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                            },
                            type: 'POST',
                            contentType: false,
                            processData: false,
                            cache: false,
                            data: datos,
                            beforeSend: function () {
                                $('form#formAsignacion input').removeClass('is-invalid');
                                $('#formAsignacion').removeClass('was-validated');
                            },
                            success: function (response) {
                                $('#formAsignacion').addClass('was-validated');
                                $('.listado').dataTable().fnDestroy();
                                $('tr#row'+id).find('td').eq(0).text(response.periodo);
                                $('tr#row'+id).find('td').eq(1).text(response.materia);
                                $('tr#row'+id).find('td').eq(2).text(response.grado);
                                $('tr#row'+id).find('td').eq(3).text(response.created_at);
                                $('tr#row'+id).find('td').eq(4).text(response.updated_at);
                                loadTable();
                                marcar();
                                toastr.options = {
                                    "closeButton": true,
                                    "debug": false,
                                    "newestOnTop": true,
                                    "progressBar": true,
                                    "positionClass": "toast-bottom-right",
                                    "preventDuplicates": false,
                                    "onclick": null,
                                    "showDuration": "400",
                                    "hideDuration": "1000",
                                    "timeOut": "5000",
                                    "extendedTimeOut": "1000",
                                    "showEasing": "swing",
                                    "hideEasing": "linear",
                                    "showMethod": "fadeIn",
                                    "hideMethod": "fadeOut"
                                };
                                toastr.success('Matrícula editada con éxito.',
                                    '¡En hora buena!');
                            },
                            error: function (msj) {
                                console.log(msj);
                                if (msj.responseJSON.error != undefined) {
                                    toastr.options = {
                                        "closeButton": true,
                                        "debug": false,
                                        "newestOnTop": true,
                                        "progressBar": true,
                                        "positionClass": "toast-bottom-right",
                                        "preventDuplicates": false,
                                        "onclick": null,
                                        "showDuration": "400",
                                        "hideDuration": "1000",
                                        "timeOut": "5000",
                                        "extendedTimeOut": "1000",
                                        "showEasing": "swing",
                                        "hideEasing": "linear",
                                        "showMethod": "fadeIn",
                                        "hideMethod": "fadeOut"
                                    };
                                    toastr.error(msj.responseJSON.error, '¡Lo sentimos!');
                                }
                                if (msj.responseJSON.errors.grado_id != undefined) {
                                    toastr.options = {
                                        "closeButton": true,
                                        "debug": false,
                                        "newestOnTop": true,
                                        "progressBar": true,
                                        "positionClass": "toast-bottom-right",
                                        "preventDuplicates": false,
                                        "onclick": null,
                                        "showDuration": "400",
                                        "hideDuration": "1000",
                                        "timeOut": "5000",
                                        "extendedTimeOut": "1000",
                                        "showEasing": "swing",
                                        "hideEasing": "linear",
                                        "showMethod": "fadeIn",
                                        "hideMethod": "fadeOut"
                                    };
                                    toastr.error(msj.responseJSON.errors.grado_id, '¡Lo sentimos!');
                                }
                                if (msj.responseJSON.errors.materia_id != undefined) {
                                    toastr.options = {
                                        "closeButton": true,
                                        "debug": false,
                                        "newestOnTop": true,
                                        "progressBar": true,
                                        "positionClass": "toast-bottom-right",
                                        "preventDuplicates": false,
                                        "onclick": null,
                                        "showDuration": "400",
                                        "hideDuration": "1000",
                                        "timeOut": "5000",
                                        "extendedTimeOut": "1000",
                                        "showEasing": "swing",
                                        "hideEasing": "linear",
                                        "showMethod": "fadeIn",
                                        "hideMethod": "fadeOut"
                                    };
                                    toastr.error(msj.responseJSON.errors.materia_id, '¡Lo sentimos!');
                                }
                            }
                        });
                    }
                },
                Cancelar: {}
            },
            onContentReady: function () {
                // bind to events
                var jc = this;
                this.$content.find('form#formAsignacion').on('submit', function (e) {
                    // if the user submits the form by pressing enter in the field.
                    e.preventDefault();
                    jc.$$editar.trigger('click'); // reference the button and click it
                });
            },
        });
    }

    function eliminar(id, url) {
        $.confirm({
            icon: 'fas fa-exclamation-triangle',
            title: '¡Advertencia!',
            content: 'Está a punto de eliminar la asignación, ¿Está seguro?',
            type: 'red',
            buttons: {
                Confirmar: {
                    btnClass: 'btn btn-danger',
                    action: function () {
                        $.ajax({
                            url: url,
                            headers: {
                                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                            },
                            type: 'DELETE',
                            success: function (response) {
                                $('.listado').dataTable().fnDestroy();
                                $('#row' + id).remove();
                                loadTable();
                                marcar();
                                toastr.options = {
                                    "closeButton": true,
                                    "debug": false,
                                    "newestOnTop": true,
                                    "progressBar": true,
                                    "positionClass": "toast-bottom-right",
                                    "preventDuplicates": false,
                                    "onclick": null,
                                    "showDuration": "400",
                                    "hideDuration": "1000",
                                    "timeOut": "5000",
                                    "extendedTimeOut": "1000",
                                    "showEasing": "swing",
                                    "hideEasing": "linear",
                                    "showMethod": "fadeIn",
                                    "hideMethod": "fadeOut"
                                };
                                toastr.success('Registro eliminado con éxito.',
                                    '¡En hora buena!');
                            },
                            error: function (msj) {
                                toastr.options = {
                                    "closeButton": true,
                                    "debug": false,
                                    "newestOnTop": true,
                                    "progressBar": true,
                                    "positionClass": "toast-bottom-right",
                                    "preventDuplicates": false,
                                    "onclick": null,
                                    "showDuration": "400",
                                    "hideDuration": "1000",
                                    "timeOut": "5000",
                                    "extendedTimeOut": "1000",
                                    "showEasing": "swing",
                                    "hideEasing": "linear",
                                    "showMethod": "fadeIn",
                                    "hideMethod": "fadeOut"
                                };
                                toastr.error('No se pudo eliminar el registro', '¡Lo sentimos!');
                            }
                        });
                    }
                },
                Cancelar: function () {},
            }
        });
    }
</script>
