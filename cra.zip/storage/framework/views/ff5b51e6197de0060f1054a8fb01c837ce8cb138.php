<?php $__env->startSection('contenido'); ?>
<section class="container">
    <h3>Listado de Asignaciones</h3>
    <hr>
    <table class="table table-responsive-sm table-hover shadow listado" id="tablaAsignaciones">
        <thead class="thead-dark">
            <tr>
                <th scope="col">Período</th>
                <th scope="col">Docente</th>
                <th scope="col">Edad</th>
                <th scope="col">Sexo</th>
                <th scope="col">Tiempo en institución</th>
                <th scope="col">Materia</th>
                <th scope="col">Grado</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $asignaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asignacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($asignacion->periodo); ?></td>
                <td><?php echo e($asignacion->docente); ?></td>
                <td><?php echo e($asignacion->edad); ?></td>
                <td><?php echo e($asignacion->sexo); ?></td>
                <td><?php echo e($asignacion->tiempoInstitucion); ?></td>
                <td><?php echo e($asignacion->materia); ?></td>
                <td><?php echo e($asignacion->grado); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>